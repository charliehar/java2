/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package arrayops;
import java.util.*;
/**
 * This method performs a linear search on the array identified by
      the first parameter, while looking for the value indicated by
      the second parameter.
      @param values, an array of integers
      @param valueToFind, an integer to look for in the array values
      @ return, the index (subscript) of the array where the value
            was found OR the length of the array if it was not found
            * 
 Complete the method, named findValue, in the class named ArrayOps.java.
 * 
 * There are two parameters to this method: 
 * the first is an integer array and the second is a integer value. 

* This method should use a linear search to try to find an
* instance of the integer value parameter within the array.
* 
* If the value is in the array,
* the method returns the subscript of the array where the value was found.
* 
* 
* If the value is not in the array,
* the value of the length of the array is returned 
* (as that is a higher value than any of the array subscripts).* 
* 
 * @author charl
 */
public class ArrayOps {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int[] values={6,1,5,7,8,2,8,9};
        int valueToFind=7;
        
        System.out.println(findValue(values,valueToFind));
    }
    public static int findValue(int values[], int valueToFind){
        //int num=0;
        //int[] newArray;
        //System.out.println(valueToFind);
        if(values.length!=0){
            for(int i=0;i<values.length;i++){
                //System.out.println(i + " "+ values[i]);
                //System.out.print(values[i]+" ");
                
                 if(values[0]==valueToFind){
                     return 0;
                 }
                 else if(values[i]==valueToFind){
                    return i;
                    //newArray = Arrays.copyOfRange(values, 0, i);
                    //num=newArray.length;
                }
                 //else{
                   //  return values.length;
                 //}
            }
        }
        System.out.println();
        return values.length;
        
        
   }
   
}