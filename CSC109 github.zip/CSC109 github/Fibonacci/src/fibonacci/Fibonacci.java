/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fibonacci;

/**
 *
 * @author charl
 */
import java.util.*;
public class Fibonacci {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner in= new Scanner(System.in);
        int n=in.nextInt();
        
        System.out.println(fib(n));
        
    }
    public static int fib(int n){
        
        
        if(n==0||n==1){
               return 1;
        }

        return fib((n-1))+fib(n-2);
    }
}
