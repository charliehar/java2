/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package arrayops1;

/**
 *
 * @author charl
 */
public class ArrayOps1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    }
    public static int bigSum(int[][] theArray)
   {
      // your work here
       int sum;
       int greater=0;
       for(int i=0; i<theArray.length;i++){
           sum=0;
           for(int j=0; j<theArray[i].length;j++){
               sum+=theArray[i][j];
           }
           if(sum>greater){
               greater=sum;
           }
       }
       return greater;

      // loop though theArray, summing first row 

      // your work here

      // loop though theArray, summing second row 

      // your work here

      // return larger sum

      // your work here

      
   }
}
