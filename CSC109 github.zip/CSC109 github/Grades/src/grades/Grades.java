/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package grades;

/**
 *
 * @author charl
 */
public class Grades {

    /**
     * @param args the command line arguments
     *
      This method examines the two arrays of test grades (double)
      identified by the two parameters, and creates an array
      containing the average values of these two arrays.
      The test scores for each student (given in the same row in each test
      array) are combined to find the average score for each student. 
      This average is placed in the corresponding row in the new array.
      @param test1, the array of scores for the first test
      @param test2, the array of scores for the second test
      @return, the array containing the average scorres
   */
    public static void main(String[] args) {
        // TODO code application logic here
        double[] test1={12,32,15};
        double[] test2={12,32,15};
        System.out.println(test1.length);
        System.out.println(makeAverage(test1,test2));
    }
    public static double[] makeAverage(double[] test1, double[] test2){
      // your work here
      int n = test1.length;
      double[] average = new double[n];
      // declare double array
      for(int i=0;i<test1.length;i++){
          average[i]=(test1[i]+test2[i])/2;
      }
      return average;
      // your work here
      
      // loop though theArray, computing each student's average
      
      // your work here
      
      // return array of averages
      
      //return test1;//makeAverage();
   }
    
}
