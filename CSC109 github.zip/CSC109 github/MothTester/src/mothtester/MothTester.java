/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mothtester;

/**
 *
 * @author charl
 */
public class MothTester {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args)
   {
      Moth gypsy = new Moth(10);
      gypsy.moveToLight(0);
      System.out.println(gypsy.getPosition());
      System.out.println("Expected: 5");
      gypsy.moveToLight(10);
      System.out.println(gypsy.getPosition());
      System.out.println("Expected: 7.5");
      gypsy.moveToLight(0);
      System.out.println(gypsy.getPosition());
      System.out.println("Expected: 3.75");
   }
    
}
