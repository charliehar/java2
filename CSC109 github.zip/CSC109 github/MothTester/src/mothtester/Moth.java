/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mothtester;

/**
 *
 * @author charl
 */
public class Moth {
    private double position;
    
    
    public Moth(double initialPosition){
        position = initialPosition;
    }
    public void moveToLight(double lightPosition){
        position -= (position-lightPosition)/2;
    }
    public double getPosition(){
        
        return position;
    }
    
}
