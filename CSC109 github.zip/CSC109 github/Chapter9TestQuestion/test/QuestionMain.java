/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author charles harwood
 * @version 0.1
 */
public class QuestionMain {
    /**
     * 
     * @param args 
     */
    public static void main(String[] args){
        Question q = new FillInQuestion("_name_fill in you name?");
                System.out.print(q.checkAnswer("name"));
    }
}
