/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *this is a fill-in question class
 * @author charl
 * @version 0.1
 */
public class FillInQuestion extends Question{
    /**
     * 
     * constructor
     * @param questionText
     * question text will answer
     */
    public FillInQuestion(String questionText) {
        super(removeAnswer(questionText));
        int start = questionText.indexOf("_");//find first underscore
        int end = questionText.lastIndexOf("_");//find last underscore
        String answer= questionText.substring(start+1, end);//extract answer
        setAnswer(answer);//set answer
        
        
    }
    /**
     * 
     * @param questionText
     * @return question without the answer text
     */
    private static String removeAnswer(String questionText){
        int start = questionText.indexOf("_");
        int end = questionText.lastIndexOf("_");
        String question= questionText.substring(0, start+1) +
                "_________"+ questionText.substring(end);
        return question;//returns the question
    }
    
}
