/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *Comments 
 * 
 * @author charles harwood 
 * @version 0.1
 */
public class QuestionTest {
    private Question instance;
    public QuestionTest() {
        instance = new Question("my Question");
    }
    
    @BeforeClass
    /**
     *
     */
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of setAnswer method, of class Question.
     */
    @Test
    public void testSetAnswer() {
        System.out.println("setAnswer");
        String correctResponse = "";
        Question instance = new Question("This a question?");
        instance.setAnswer(correctResponse);
        boolean answer = instance.checkAnswer(correctResponse);
        assertTrue(answer);
        correctResponse="answer";
        instance.setAnswer(correctResponse);
        answer=instance.checkAnswer("");
        assertFalse(answer);
        //assertEquals(10.0, 10.0, 0.01);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of checkAnswer method, of class Question.
     */
    @Test
    public void testCheckAnswer() {
        //System.out.println("checkAnswer");
        System.out.println("setAnswer");
        String correctResponse = "";
        Question instance = new Question("This a question?");
        instance.setAnswer(correctResponse);
        boolean answer = instance.checkAnswer(correctResponse);
        assertTrue(answer);
        correctResponse="answer";
        instance.setAnswer(correctResponse);
        answer=instance.checkAnswer("");
        assertFalse(answer);
        //String response = "";
        //Question instance = null;
        //boolean expResult = false;
        //boolean result = instance.checkAnswer(response);
        //assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of display method, of class Question.
     */
    @Test
    public void testDisplay() {
        System.out.println("display");
        Question instance = null;
        instance.display();
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
        assertTrue(true);
    }
    
}
