/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package arrayops2;

/**
 *
 * @author charl
 */
import java.util.*;
public class ArrayOps2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    }
    public static ArrayList copyReverse(int[] anArray)
   {
      // declare new ArrayList
       ArrayList<Integer> reverse= new ArrayList<Integer>();
       for(int i=anArray.length-1;i>=0;i--){
           reverse.add(anArray[i]);
       }

      // your work here

      // loop though anArray, in reverse,
      // storing each element in the ArrayList

      // your work here

      // return new ArrayList

      // your work here
      return reverse;
   }
}
