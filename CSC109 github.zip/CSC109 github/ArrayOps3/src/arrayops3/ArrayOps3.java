/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package arrayops3;

/**
 *
 * @author charl
 */
import java.util.*;
public class ArrayOps3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        int[]anArray={3,2,5,3,2,7,8,2,5};
        System.out.println(copyArray(anArray));
    }
     /**
       This method goes through the array of integers identified by
       the only parameter, creating a new ArrayList from the array,
       eliminating duplicates from the original array.
       @param theArray, an array of integer
       @return uniqueIntAL, the new ArrayList

   */
   public static ArrayList copyArray(int[] anArray)
   {
      // your work here

      // declare the new ArrayList
       ArrayList<Integer> copy= new ArrayList<Integer>();
       for(int i=0; i<anArray.length;i++){
           if(!copy.contains(anArray[i])){
               copy.add(anArray[i]);
           }
            
               
           }
       
       
       
       
       return copy;

   }

}
