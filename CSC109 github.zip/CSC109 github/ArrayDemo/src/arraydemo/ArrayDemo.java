/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package arraydemo;

/**
 *
 * @author charl
 */
import java.util.*;
public class ArrayDemo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        int[] numbers;
        numbers =new int[20];
        
        double [] dnumbers=new double[30];
        
        String[] snames=new String[10];
        
        String[] familyNames = {"Smith", "Loi","Ramos"};
        
        System.out.println("familyNames length is "+ familyNames.length);
        
        for(int i=0; i<familyNames.length;i++){
            System.out.println("Family name: "+familyNames[i]);
            
        }
      System.out.println("2nd position: "+ familyNames[1]);
      
      String famName=familyNames[0];
      System.out.println("name: "+ famName);
      familyNames[1]="Russo";
      System.out.println("Changed family Name: "+ familyNames[1]);
    }
    
}//18:54
