/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bugtester;

/**
 *
 * @author charl
 */
public class Bug {
  /**
      Constructs a bug with a given position, facing right.
      @param initialPosition the initial position
   */
   private int position;
   private boolean direction;
   public Bug(int initialPosition)
   {
      position = initialPosition;
      direction = true;
   }
   
   /**
      Moves the bug by one unit in the current direction.
   */
   public void move()
   {
      if(direction){
          position++;
      }
      else{
          position--;
      }
   }
   
   /**
      Flips the direction of this bug. 
   */
   public void turn()
   {
      if(direction){
          direction=false;
      }
      else{
          direction=true;
      }
   }
   
   /**
      Gets the current position of this bug.
      @return the position
   */
   public int getPosition()
   {
      return position;
   }
   
}
