/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bugtester;

/**
 *
 * @author charl
 */
public class BugTester {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args)
   {
      Bug lady = new Bug(10);
      //Bug bugsy = new Bug(10);
      lady.move(); // now the position is 11
      lady.turn();
      lady.move();
      // make the bug move and turn a few times
      lady.move();
      lady.move();
      lady.move();
      lady.move();
      
      // print the actual and expected position
      System.out.println(lady.getPosition());
      System.out.println("Expected: 18");
   }
    
}
