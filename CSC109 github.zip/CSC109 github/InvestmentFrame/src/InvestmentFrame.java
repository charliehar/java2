
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author charl
 */
public class InvestmentFrame extends JFrame {
    
    private double balance;
    private JButton button;
    private JLabel label;
    
    public InvestmwntFrame(){
        
    }
}
