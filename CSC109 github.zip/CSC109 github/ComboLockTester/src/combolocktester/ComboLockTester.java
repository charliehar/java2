/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package combolocktester;

/**
 *
 * @author charl
 */
public class ComboLockTester {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int secret1=5;
        int secret2=31;
        int secret3=1;
        ComboLock lock = new ComboLock(secret1,secret2,secret3);
        lock.turnRight(5);
        lock.turnLeft(31);
        lock.turnRight(1);
        lock.reset();
        System.out.println(lock.open());
    }
    
}
