/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package combolocktester;

/**
 *
 * @author charl
 */
public class ComboLock {
    private int mySecret1,mySecret2,mySecret3;
    private int fNum,sNum,tNum;
    private boolean turn1,turn2,turn3;
    
    
    
    public ComboLock(int secret1, int secret2, int secret3){
        mySecret1 = secret1;
        mySecret2=secret2;
        mySecret3=secret3;
        fNum=-1;
        sNum=-1;
        tNum=-1;
        turn1=false;
        turn2=false;
        turn3=false;
    }
    public void reset(){
        fNum=-1;
        sNum=-1;
        tNum=-1;
        turn1=false;
        turn2=false;
        turn3=false;
    }
    public void turnLeft(int ticks){
         if(!turn2){
             sNum=ticks;
             turn2=true;
         }
    }
    public void turnRight(int tick){
        if(!turn1){
            fNum=tick;
            turn1=true;
        }
        else if(!turn3){
            tNum=tick;
            turn3=true;
        }
    }
    public boolean open(){
        if(fNum==mySecret1&&sNum==mySecret2&&tNum==mySecret3)
            return true;
        return false;
    }
}
