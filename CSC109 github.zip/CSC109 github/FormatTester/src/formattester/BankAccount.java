/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package formattester;

/**
 *
 * @author charl
 */
public class BankAccount {
    private double myBalance;
    private String balanceToString;
    public BankAccount(double balance){
        myBalance=balance;
        balanceToString=Double.toString(myBalance);
    }
    public String toString(){
        
        
        return String.format("%s",balanceToString);
    }
}
