/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package computepay;

/**
 *
 * @author charl
 */
public class ComputePay {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        double wage=10;
        double hoursWorked=50;
        double pay=0;
        if(hoursWorked<=40)
           pay= hoursWorked *wage;
        else{
            pay=(40*wage)+((hoursWorked%40)*wage*1.5);
            
            
        }
       return pay;
        
        
    }
    
}
