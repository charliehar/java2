


/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author charl
 */
public class EmployeeTester {
     
      System.out.println(e);
      System.out.println("Expected: Employee[name=Edgar,salary=65000.0]");
      System.out.println(m);
      System.out.println("Expected: Manager[super=Employee[name=Mary,salary=85000.0],department=Engineering]");
      System.out.println(v);
      System.out.println("Expected: Executive[super=Manager[super=Employee[name=Veronica,salary=105000.0],department=Engineering]]");
}
