/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package palfind;

/**
 *
 * @author charl
 */
/**
   Reads a string, checks to see if it is a palindrome, and prints
      "Yes" or "No", accordingly. 
   Input: the value of s, a string
   Output: "Yes" or "No"
*/

import java.util.*;
public class PalFind{

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        // Read string and convert to lowercase
      Scanner in = new Scanner(System.in);
      String ins = in.nextLine();
      //System.out.println(ins);
      String out="";
      int len= ins.length();
      
      for(int i=len-1;i>=0;i--){
          out+=ins.charAt(i);
          
      }
      if(out.equalsIgnoreCase(ins))
          System.out.println("Yes");
      else{
          System.out.println("No");
      }
          
    }
    
}
