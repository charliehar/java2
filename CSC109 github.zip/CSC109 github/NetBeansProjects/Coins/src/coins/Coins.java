/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package coins;

/**
 *
 * @author charl
 */
import java.util.*;
public class Coins {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        // Define constants
      final String P_TYPE = "P";
      final String N_TYPE = "N";
      final String D_TYPE = "D";
      final String Q_TYPE = "Q";
      double value=0;

      // Read a number and type of coin 
      System.out.println("Enter number and type of coins: ");

      Scanner in = new Scanner(System.in);
      int numCoins = in.nextInt();
      String typCoin = in.next();
      switch(typCoin){
        
          case P_TYPE:
              value= numCoins * .01;
              System.out.printf("$%.2f\n", value);
              break;
          case N_TYPE:
              value= numCoins * .05;
              System.out.printf("$%.2f\n", value);
              break;
          case D_TYPE:
              value= numCoins * .1;
              System.out.printf("$%.2f\n", value);
              break;
          case Q_TYPE:
              value= numCoins * .25;
              System.out.printf("$%.2f\n", value);
              break;
          default:
              System.out.println("ERROR");
              break;
      }

      // Determine and print worth of coin pile

      // Your work here

      
    }
    
}
