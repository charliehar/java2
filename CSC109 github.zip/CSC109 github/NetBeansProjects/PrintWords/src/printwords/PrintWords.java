/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package printwords;

/**
 *
 * @author charl
 */
import java.util.*;
public class PrintWords {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner in = new Scanner(System.in);
        System.out.println("Please enter a number:");
        int n= in.nextInt();
        
        if(n==0){
            System.out.println("zero");
            
        }
        else if(n==1){
            System.out.println("one");
            
        }
        else if(n==2){
            System.out.println("two");
            
        }
        else if(n==3){
            System.out.println("three");
            
        }
        else if(n==4){
            System.out.println("four");
            
        }
        else if(n==5){
            System.out.println("five");
            
        }
        else if(n==6){
            System.out.println("six");
            
        }
        else if(n==7){
            System.out.println("seven");
            
        }
        else if(n==8){
            System.out.println("eight");
            
        }
        else if(n==9){
            System.out.println("nine");
            
        }
        
        
        
        
        
        
        
    }
    
}
