/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bankinterest;

/**
 *
 * @author charl
 */
import java.util.*;
public class BankInterest {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        // Define constants
      final double HI_RATE = 2.75;
      final double MD_RATE = 2.00;
      final double LO_RATE = 1.00;
      final double ZERO_RATE = 0.00;
      final double DEB_CHG = -25.00;

      final double HI_LIMIT = 100000.00;
      final double MD_LIMIT = 25000.00;
      final double LO_LIMIT = 10000.00;
      final double ZERO_LIMIT = 0.00;

      // Print prompt to enter a current balence
      System.out.print("Enter current balance: ");

      // Read balance
      Scanner in = new Scanner(System.in);
      double balance = in.nextDouble();
      double newBalance=0;

      // Determine interest rate (or charge) based on current balance
      //   to compute new balance

      // Your work here
      if (balance>HI_LIMIT){
          newBalance = balance * (1.00+(HI_RATE/100.00));
      }
      else if (balance>MD_LIMIT){
          newBalance = balance * (1.00+(MD_RATE/100.00));
      }
      else if (balance>LO_LIMIT){
          newBalance = balance * (1.00+(LO_RATE/100.00));
      }
      else if (balance>=ZERO_LIMIT){
          newBalance = balance * (1.00+(ZERO_RATE/100.00));
      }
      else{
          newBalance = balance +DEB_CHG;
      }

      System.out.printf("%.2f\n", newBalance);
    }
    
}
