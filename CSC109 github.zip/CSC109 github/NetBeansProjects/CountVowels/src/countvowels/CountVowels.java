/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package countvowels;

/**
 *
 * @author charl
 */
/**
   Reads a string and counts all vowels contained in that string.
   Vowels are A E I O U a e i o u. 

   Input: the value of s, a string
   Output: the number of all the vowels in s
   * hello world
   * eoo
   * 3
*/

import java.util.*;
public class CountVowels {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
      Scanner in = new Scanner(System.in);
      String s = in.nextLine();
      String vowels="AEIOUaeiou";
      int totVow=0;
      
      
      for(int i =0;i<s.length();i++){
          
          if(vowels.contains(s.subSequence(i, i+1))){
              totVow++;
          }
          
          
      }
      System.out.println(totVow);
    }
    
}
