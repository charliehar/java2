/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package multtable;

/**
 *
 * @author charl
 */
public class MultTable {

    /**
    y | 1y | 2y | 3y | 4y | 5y 
  ----|----|----|----|----|----
    1 |  1 |  2 |  3 |  4 |  5
    2 |  2 |  4 |  6 |  8 | 10
    3 |  3 |  6 |  9 | 12 | 15
    4 |  4 |  8 | 12 | 16 | 20
    5 |  5 | 10 | 15 | 20 | 25
    6 |  6 | 12 | 18 | 24 | 30
    7 |  7 | 14 | 21 | 28 | 35
    8 |  8 | 16 | 24 | 32 | 40
    9 |  9 | 18 | 27 | 36 | 45
   10 | 10 | 20 | 30 | 40 | 50

     * @param args the command line arguments
     */
    public static void main(String[] args) {
        System.out.println("  y | 1y | 2y | 3y | 4y | 5y ");
        System.out.println("----|----|----|----|----|----");
        System.out.println("  1 |  1 |  2 |  3 |  4 |  5");
        System.out.println("  2 |  2 |  4 |  6 |  8 | 10");
        System.out.println("  3 |  3 |  6 |  9 | 12 | 15");
        System.out.println("  4 |  4 |  8 | 12 | 16 | 20");
        System.out.println("  5 |  5 | 10 | 15 | 20 | 25");
        System.out.println("  6 |  6 | 12 | 18 | 24 | 30");
        System.out.println("  7 |  7 | 14 | 21 | 28 | 35");
        System.out.println("  8 |  8 | 16 | 24 | 32 | 40");
        System.out.println("  9 |  9 | 18 | 27 | 36 | 45");
        System.out.println(" 10 | 10 | 20 | 30 | 40 | 50");
    }
    
}
