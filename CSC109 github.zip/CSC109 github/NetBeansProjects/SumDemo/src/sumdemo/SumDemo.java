/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sumdemo;
import java.util.*;
/**
 *
 * @author charl
 */
public class SumDemo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        Scanner in=new Scanner(System.in);
        //System.out.println("Please enter a salary. Enter -1 to stop");
        double salary=0.00;
        double sum= 0.00;
        
        while(in.hasNextDouble()){
            salary = in.nextDouble();
            sum+=salary;
            System.out.println("Sum: " +sum);
            System.out.println("Please enter a salary. Enter q to stop");
            
           
        }
        System.out.println("Sum: " +sum);
    }
    
}
