/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package getvowels;

/**
 *
 * @author charl
 */
import java.util.*;
public class GetVowels {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
      String r = "";
      
      Scanner in = new Scanner(System.in);
      String s = in.nextLine();
      int len= s.length();
      String vowels="AEIOUaeiou";
      

      // your work here
      for(int i=0; i<len;i++){
          
          if(vowels.contains(s.substring(i,i+1))){
              r+=(s.substring(i,i+1));
          
      }
    }

      System.out.println(r);
    }
    
}
