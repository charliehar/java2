/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package larger;

/**
 *
 * @author charl
 */
import java.util.*;
public class Larger
{
   public static void main(String[] args)
   {
      // Print prompt to enter two integer values
      System.out.print("Please enter two integer values: ");

      // Read in both integer values
      Scanner in = new Scanner(System.in);
      int value1 = in.nextInt();
      int value2 = in.nextInt();
      
      if(value1>value2){
          System.out.println(value1);
      }
      else if(value2>value1){
          System.out.println(value2);
      }
      else{
       System.out.println(value1);
      }
      // Determine which value is larger and print it out

      // Your work here

   }
}

