/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ti;

/**
 *
 * @author charl
 */
public class TI {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
          String one="Harry";
          String two="Joseph";
          String three="Potter";
          //String concat=one.charAt(0)+two.charAt(0)+three.charAt(0);
          
          return (one.substring(0,1)+two.substring(0,1)+three.substring(0,1));
          
          /*
        one.charAt(0)+ two.charAt(0)+three.charAt(0) ;
           your work here
        String init1= one.char(0);
        init = one.charAt(0)+two.charAt(0)+three.charAt(0);
       */
    }
    
}
