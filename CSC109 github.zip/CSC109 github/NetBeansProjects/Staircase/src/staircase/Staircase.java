/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package staircase;

/**
 *
 * @author charl
 *
  ____
  I__I___
  I_____I___
  I________I___
  I___________I___
  I______________I___


Use the underscore character (_) and the uppercase I. 

 */
public class Staircase {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
      System.out.println("  ____");
      System.out.println("  I__I___");
      System.out.println("  I_____I___");
      System.out.println("  I________I___");
      System.out.println("  I___________I___");
      System.out.println("  I______________I___");
    }
    
}
