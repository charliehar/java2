/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lexiorder;

/**
 *
 * @author charl
 */
import java.util.*;
public class LexiOrder {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        // Print prompt to enter two words (strings)
      System.out.println("Please enter two words: ");

      // Read in both integer values
      Scanner in = new Scanner(System.in);
      String word1 = in.next();
      String word2 = in.next();
      
      if(word1.compareTo(word2)<0){
          System.out.println(word1 + " "+word2);
      }
      else if(word1.compareTo(word2)>0){
          System.out.println(word2+ " "+word1);
      }
      else{
          System.out.println(word1+" "+ word2);
      }
      

      // Determine the correct alphabetical order of words
      //    and print out the words in one line, in order.

      // Your work here

    }
    
}
