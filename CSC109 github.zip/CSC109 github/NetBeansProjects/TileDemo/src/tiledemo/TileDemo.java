/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
   2:49:08
 */
package tiledemo;

/**
 *
 * @author charl
 */
import java.util.*;
public class TileDemo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int width=0;
        
        System.out.println("Please enter the width: ");
        Scanner in = new Scanner(System.in);
        width = in.nextInt();
        
        // 20 / 2 = 10 - 1 = 9
        // 20 - 1
        // 19 
        
        int numTiles = 0;
        
        if(width % 2 == 0){ // even number
            //width-1
            numTiles = width - 1;
        }
        /*else{ //odd number   not always needed
            // do nothing
            numTiles = width;
        }*/
        System.out.println("Number of tiles: " + numTiles);
        
        
        
        
    }
    
}
