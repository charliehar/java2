/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package smallest;

/**
 *
 * @author charl
 */
import java.util.*;
public class Smallest {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        // Print prompt to enter three integer values
      System.out.print("Please enter three integer values: ");

      // Read in the three integer values
      Scanner in = new Scanner(System.in);
      int value1 = in.nextInt();
      int value2 = in.nextInt();
      int value3 = in.nextInt();
      
      if(value1<=value2 && value1<=value3){
          System.out.println(value1);
      }
      else if(value2<=value1 && value2<=value3){
          System.out.println(value2);
      }
      else{
          System.out.println(value3);
      }
      
      
      
      
      

    }
    
}
