/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package stringgames;

/**
 *
 * @author charl
 */
/**
   A program reads in a string,
   prints out the last character of the string,
   followed by the first character, and then
   followed by the three middle character of the string.
   All input strings should be of odd length.
*/
import java.util.*;
public class StringGames
{
   public static void main (String[] args)
   {
      // Display prompt for input string
      System.out.println("Please enter a string: ");

      // Read string
      Scanner in = new Scanner(System.in);
      String input = in.next();
      int n= input.length();

      // Put together new string and print

      // Your work here
      //char lLetter = input.charAt(n-1);
      //char fLetter = input.charAt(0);
      
      System.out.println(input.substring(n-1)+ input.substring(0,1)+ input.substring(n/2-1, n/2+2));
   }
}