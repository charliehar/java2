/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package converttemp;

/**
 *
 * @author charl
 */
import java.util.*;
public class ConvertTemp
{
   public static void main (String[] args)
   {
      // Define constants

      // Your work here

      // Display prompt for temperature in degrees Farhenheit
      System.out.print("Please enter the temperature ");
      System.out.print("in degrees Farhenheit: ");

      // Read Fahrenheit temperature
      Scanner in = new Scanner(System.in);
      double fahrenheit = in.nextDouble();
      double celsius=(5.0/9)*(fahrenheit-32.0);
      double kelvin=celsius+273.0;

      // Compute Celsius and Kelvin equivalents

      // Your work here

      // Print out equivalents
      System.out.println(celsius);
      System.out.println(kelvin);
   }
}
