/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package wordavg;

/**
 *
 * @author charl
 */
/**
   Determines the average number of characters for words in a string.   
   Input: a string of one or more lines containing words
   Output: the average number of characters per word in the string 
      to two decimal places
*/
import java.util.*;
public class WordAvg {
public static void main(String [] args){

        int totWrds = 0;
        int totalLength = 0;
        String word = "";
        double wordAverage=0.0;

            Scanner ins = new Scanner(System.in);
            while (ins.hasNext()) {
                String token = ins.nextLine();
                Scanner parser = new Scanner(token);
                while (parser.hasNext()){
                    word = parser.next();
                    totWrds++;
                    totalLength+= word.length();
                }
                break;
            }
        wordAverage= (double) totalLength/totWrds;
        System.out.printf("%.2f\n",wordAverage);

        
        
    }
    
}
