/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lines;

/**
 *
 * @author charl
 */
import java.util.*;
public class Lines {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code appl// Read coordinates
      Scanner in = new Scanner(System.in);
      double x1 = in.nextDouble();
      double y1 = in.nextDouble();
      double x2 = in.nextDouble();
      double y2 = in.nextDouble();
      
      //double a= x2-x1;
      //double b= y2-y1;
      //double c= Math.sqrt(Math.abs(a)+Math.abs(b));
      // Compute and print out the length of the line segment
      double length = Math.hypot(x2 - x1, y2 - y1);
      // Your work here
      

      
      
      System.out.println(length);
        
    }
    
}
