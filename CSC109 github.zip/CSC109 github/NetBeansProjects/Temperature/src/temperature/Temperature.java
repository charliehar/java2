/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package temperature;

/**
 *
 * @author charl
 */
import java.util.*;
public class Temperature
{
   public static void main (String[] args)
   {
      // Define constants

      // Your work here

      // Display prompt for temperature in degrees Farhenheit or Celsius
      System.out.print("Please enter the temperature in degrees: ");

      // Read temperature
      Scanner in = new Scanner(System.in);
      double temp = in.nextDouble();

      // Display prompt for character that denotes type of temperature
      System.out.print("Enter F for Farhenheit or C for Celsius: ");
      double Celsius= (5/9.0)*(temp-32.0);
      double Farhenheit = (9/5.0)*temp + 32.0;

      // Read character denoting type of temperature
      String type = in.next();
      String farhenheit= "f";
      String celsius = "c";
      if(type.equalsIgnoreCase(farhenheit)){
          System.out.println(Celsius + " degrees Celsius");
      }
      else if(type.equalsIgnoreCase(celsius)){
          System.out.println(Farhenheit + " degrees Farhenheit");
      }
      else{
          
      }

      // Compute and print Celsius or Farhenheit equivalent

      // Your work here

   }
}