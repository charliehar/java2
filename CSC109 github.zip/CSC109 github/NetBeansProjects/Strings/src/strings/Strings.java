/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package strings;

/**
 *
 * @author charl
 */
import java.util.*;
public class Strings {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
         // Display prompt for string of characters
      System.out.println("Please enter a string: ");

      // Read string
      Scanner in = new Scanner(System.in);
      String str = in.nextLine();

      // Display prompt for integer n
      System.out.println("Please enter a value for n: ");

      // Read n
      int n = in.nextInt();
      

      // Print last n characters of string
      int length = str.length();
      

      // Your work here
      if(length==0){
          System.out.println("");
      }
      
      else{
           
           System.out.println(str.substring(length-n,length));
              }
      
    }
    
}
