/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package investmentincome;

/**
 *
 * @author charl
 */
import java.util.*;
public class InvestmentIncome {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int year = 0;
        double balance = 0;
        double RATE= 0;
        double interest=0;
        double endBalance=0;
        
        
        //System.out.println("Please enter a double value:");
        System.out.println("Please enter a beginning balance:");
        Scanner in = new Scanner(System.in);
        balance = in.nextDouble();
        System.out.println("Please enter an interest rate:");
        RATE = in.nextDouble();
        
        
        
        year = year+1;
        System.out.printf("%10.2f\n%10.2f\n%10d\n", balance, RATE, year);
        interest = balance * RATE;
        
        endBalance= interest + balance;
        System.out.println("End Balance = "+endBalance);
        
        endBalance = Math.pow(balance, 2);
        
        String fname = "Charles";
        String lname = "Harwood";
        String fullName = fname + " " + lname;
        
        // a space in a string counts as a character
        //String fname = "";
        //String lname = "";
        
        System.out.println("first character:" + fullName.charAt(0));
        System.out.println("second character:" + fullName.charAt(1));
        System.out.println("third character:" + fullName.charAt(2));
        
        System.out.println("three characters:" + fullName.substring(0,3));
        System.out.println("three characters:" + fullName.substring(3));
        
        
        
        String[] name = fullName.split(" ");
        System.out.println("First name: " + name[0]);
         System.out.println("Last name: " + name[1]);
        int fnameLength = fname.length();
        //System.out.println("First name length:" + fnameLength);
        System.out.println("Full name: " + fname + " " + lname);


        /*fname.length();
        
        int i, j, k;
        double m;
        
        m=10.5;
        i=5;
        j=7;
        k=2;
        k=i/j;
        m=i/j;
        m=i + j * k;
        System.out.println("k: " + k);
        __________________________
        
        ascii table
        Notes
        naming conventions
        math with the data types
        8 data types
        all of the libraries
        math library
            to activate the math library use Math.
                example  Math.pow(y,2); is y to the 2nd power
        
        m=(i+j)*k;
        System.out.println("m: " + m);
        _________________________
        double p = i+j;
        double base = 100;
        double pennies = 1729;
        double dollars = (int) (pennies / 100);
        double x = m / 10.0;
        __________________________
        System.out.println("Dollars: " +dollars);
        */
        
    }
    
}
