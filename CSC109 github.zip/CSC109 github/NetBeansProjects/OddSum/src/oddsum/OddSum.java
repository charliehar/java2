/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package oddsum;

/**
 *
 * @author charl
 */
/**
   Computes a sum of odd integers between two bounds. 
   Input: a, the lower bound (may be odd or even).
   Input: b, the upper bound (may be odd or even).
   Output: sum of odd integers between a and b (inclusive).
*/
import java.util.*;
public class OddSum {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
      Scanner in = new Scanner(System.in);
      System.out.println("Please enter a number.");
      int a = in.nextInt();
      System.out.println("Please enter a number.");
      int b = in.nextInt();
      long sum=0;

      // your work here
      for(int i = a;i<=b;i++){
          
          if(Math.abs(i)%2==1){
              sum+=i;
              
          }
          //else{
            //  sum=sum;
          //}
          
      }

        System.out.println(sum);
        //System.out.println("test" + ((-10)%3));
    }
    //9 to 99999 yeilds -179467312
    //99999 to 10000 yeilds 0
}
