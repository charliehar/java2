/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package spellnumbers;

/**
 *
 * @author charl
 */
public class testnumbers {
    public static void main(String[] args){
        int value=12345;
        
        while(value>0){
            int tmpnum=value%1000;
            System.out.println(value);
            System.out.println(tmpnum);
            value = value/1000;
        }
    }
}
