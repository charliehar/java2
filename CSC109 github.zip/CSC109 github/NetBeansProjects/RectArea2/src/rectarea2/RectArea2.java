/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rectarea2;
import java.util.Scanner;
/**
 *
 * @author charl
 */
public class RectArea2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner in = new Scanner(System.in);
      
      // Display prompt for rectangle width
      System.out.print("Please enter the width of the rectangle: ");

      // Read height of rectangle
      double width =0;
      width = in.nextDouble();
      double height=0;
      double area=0;

      // Display prompt for rectangle height
      System.out.print("Please enter the height of the rectangle: ");

      // Read height of rectangle
      height = in.nextDouble();
      
      area = width*height;

      // Compute and print result
      System.out.println("The area is: " +area);
      

    }
    
}


/**
   A program that prompts for the height and width of a rectangle
   and prints the area of that rectangle.  
   All variables should be of type double.
