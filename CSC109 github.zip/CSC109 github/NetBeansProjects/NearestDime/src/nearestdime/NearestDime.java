/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package nearestdime;

/**
 *
 * @author charl
 */
import java.util.*;
public class NearestDime {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
      System.out.print("Please enter the price: ");
      Scanner in = new Scanner(System.in);
      double price = in.nextDouble();
      int pennies = (int) Math.round(price * 100);

      // Determine dollar and cents worth of pennies 
      int cents;
      int dollars;

      // Your work here     

      // Round cents to nearest dime
      int dimes=0;

      // Your work here
      dollars=pennies/100;
      cents= pennies%100;
      
      if(cents%10<5){
          dimes = cents/10;
      }
      else{
          dimes=cents/10+1;
      }

      // Print revised price
      double revised = dollars + dimes * 0.1;
      System.out.printf("%.2f\n", revised);   
    }
    
}
