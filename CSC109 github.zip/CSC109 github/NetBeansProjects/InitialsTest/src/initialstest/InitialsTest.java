/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package initialstest;

/**
 *
 * @author charl
 */
public class InitialsTest
{
   /**
      Gets the initials of this name
      @params first, middle, and last names
      @return a string consisting of the first character of the first, middle,
      and last name
   */
   public static String getInitials(String one, String two, String three)
   {
       
     return (one.substring(0,1)+two.substring(0,1)+three.substring(0,1));

   }
}

