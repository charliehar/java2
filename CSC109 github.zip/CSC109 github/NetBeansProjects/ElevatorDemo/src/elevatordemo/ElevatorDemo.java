/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package elevatordemo;

/**
 *
 * @author charl
 */
import java.util.*;
public class ElevatorDemo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        System.out.println("Please enter a floor number:");
        Scanner in = new Scanner(System.in);
        
        int floor = in.nextInt();
        int actualFloor=floor;
        
        //if(floor>12){
          //  floor++;
        //}
        System.out.println("Floor " + floor);
        
        if(floor>=5){
            actualFloor=floor -1;
        }
        else if(floor>=15){
            actualFloor=floor -2;
        }
        else if(floor>=25){
            actualFloor=floor -3;
        }
        else{
            actualFloor=floor;
        }
        System.out.println(actualFloor);
    }
    
}
