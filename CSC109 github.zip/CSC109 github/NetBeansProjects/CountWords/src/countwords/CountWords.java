/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package countwords;

/**
 *
 * @author charl
 */
import java.util.*;
public class CountWords {
    public static void main(String [] args){

        int totWrds = 0;
        int totalLength = 0;
        String word = "";

            Scanner ins = new Scanner(System.in);
            while (ins.hasNext()) {
                String token = ins.nextLine();
                Scanner parser = new Scanner(token);
                while (parser.hasNext()){
                    word = parser.next();
                    totWrds++;
                    
                }
                break;
            }
        System.out.println(totWrds);
    }
}
