/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package computefact;

/**
 *
 * @author charl
 *Given a positive number n, the factorial of that number, denoted n!,
 is equal to 1 × 2 × ... × (n-1) × n.
  * It can also be computed recursively: n! = n × (n-1)!, for all n greater
  * than or equal to zero
 * For example, 
 3! = 3 × 2! 
    = 3 × 2 × 1!
    = 3 × 2 × 1
    = 3 × 2
    = 6
By convention, 0! is 1
 * 
      A method to compute n factorial (n!) recursively
      @param n a number >= 0
      @return the value of n!
      * 
   */
import java.util.*;
public class ComputeFact {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner in=new Scanner(System.in);
        int n=in.nextInt();
        System.out.println(factorial(n));
        
    }
    public static int factorial(int n)
   {
       
       if(n==1){
           return 1;
       }
       return n*factorial(n-1);
   }
}
