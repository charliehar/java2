/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package notes;

/**
 *
 * @author charl
 */
public class Notes {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        /*when using webcat use default package
        try to avoid using multiple if statements
        try to avoid mixing different types of loops
        organize code
        test cases for while loops and all loops
            look for infinite loop possibilities
            while can 3 different test results
                did not run
                ran but ended
                infinite loop
        white box vs black box testing
        cannot test gui class
        
        abstract proposal 250
        
        use classes when creating charts
        */
        
    }
    
}
