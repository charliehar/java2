/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package examaverage;

/**
 *
 * @author charl
 */
//import java.io.*;
//import java.util.*;
import java.io.FileReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.io.PrintWriter;
public class ExamAverage {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args)throws FileNotFoundException{
      String inputFileName = "C:\\Users\\charl\\Documents\\scores.txt";
      String outputFileName = "C:\\Users\\charl\\Documents\\examScoreAverage.txt";
      File inputFile=new File(inputFileName);
      Scanner in = new Scanner(inputFile);
      PrintWriter out = new PrintWriter(outputFileName);
      
      int count=0;
      double total=0;
      double score;
      while(in.hasNextDouble()){
          count++;
          score=in.nextDouble();
          out.println("Score "+ count+": "+score);
          total+=score;
      }
      out.println("Number of scores read: " + count);
      out.println("Average Score: " + (total/count));
      // TODO: Open the input and output files.
      // Read records from the input file.
      // Calculate the average score.
      // Write each exam score, the count of scores read,
      // and the average score to the output file.
      in.close();
      out.close();
   }
    
}
