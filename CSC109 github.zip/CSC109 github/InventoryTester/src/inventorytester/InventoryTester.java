/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package inventorytester;

/**
 *
 * @author charl
 */
public class InventoryTester {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        Inventory item1 = new Inventory();
        Inventory item2 = new Inventory();
        
        item1.setName("MP3 Player");
        item1.setPrice(42.65);
        item1.setQuantity(2);
        
        item2.setName("IPhone");
        item2.setPrice(99.95);
        item2.setQuantity(4);
        
        
        
        System.out.println(item1.getName()+"\n"+item1.getPrice()+"\n"+item1.getQuantity());
        System.out.println(item2.getName()+"\n"+item2.getPrice()+"\n"+item2.getQuantity());
    }
    
}
