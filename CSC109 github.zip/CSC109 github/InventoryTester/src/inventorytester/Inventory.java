/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package inventorytester;

/**
 *
 * @author charl
 */
public class Inventory {
    private String name;
    private double price;
    private int quantity;
    private int sold;
    
    public Inventory(){
        
    }
    public void setName(String productName){
        name=productName;
        
    }
    public void setPrice(double productPrice){
        price=productPrice;
        
    }
    public void setQuantity(int productQuantity){
      quantity=productQuantity;
        
    }
    public void setSold(int productSold){
       sold=productSold;
       
    }
    public String getName(){
        
        return name;
    }
    public double getPrice(){
        
        return price;
    }
    public int getQuantity(){
        
        return quantity;
    }
    public int getSold(){
        
        
        return sold;
    }
}
