/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cartester;

/**
 *
 * @author charl
 */
public class CarTester {

    /**
     * @param args the command line arguments
     */
    public static void main(String [] args)
   { 
      Car myHybrid = new Car(50); // 50 miles per gallon       
      myHybrid.addGas(20); 
      myHybrid.drive(100); // consumes 2 gallons      
      double gasLeft = myHybrid.getGasInTank(); 
      double expected=18.0;
      // TODO: Print actual and expected gas level
     System.out.printf("Actual:"+gasLeft +"\n"+"expected:" +gasLeft);
     
   } 
    
}
