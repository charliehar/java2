/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cartester;

/**
 *
 * @author charl
 */
public class Car {
   private double gas;
   private double efficiency;

   /** 
      Constructs a car with a given fuel efficiency. 
      @param anEfficiency the fuel efficiency of the car 
   */ 
   public Car(double anEfficiency) 
   {
      //yourworkhere
       efficiency=anEfficiency;
       gas=0;
   }

   /** Adds gas to the tank. 
       @param amount the amount of fuel to add 
   */ 
   public void addGas(double amount) 
   { 
      //yourworkhere
      gas +=amount;
      
   } 

   /** 
       Drives a certain amount, consuming gas. 
       @param distance the distance driven 
   */ 
   public void drive(double distance) 
   { 
      //yourworkhere
      gas-=(distance/efficiency);
       
   } 

   /** 
       Gets the amount of gas left in the tank. 
       @return the amount of gas 
   */ 

   public double getGasInTank() 
   {
      //yourworkhere
      
      return gas;
   } 
}
