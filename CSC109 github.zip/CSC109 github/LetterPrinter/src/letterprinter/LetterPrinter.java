/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package letterprinter;
import java.util.*;
/**
 *
 * @author charl
 */
public class LetterPrinter {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
      
        String from = "Charlie";
        String to="lou";
        Letter myLetter=new Letter(from, to);
        myLetter.addLine("This is a test");
        myLetter.addLine("How are you?");
        System.out.println(myLetter.getText());
        
     
        // TODO code application logic here
    }

}
