/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package letterprinter;

/**
 *
 * @author charl
 */
public class Letter {
       
   private String sender;
   private String recipient;
   private String body;
   private String letter;

   /**
      Constructs a letter with a given sender and recipient.
      @param from the sender
      @param to the recipient
   */
   public Letter(String from, String to)
   {
       sender =from;
       recipient=to;
       body="";
       letter="";
       
   }
   
   /**
      Adds a line to the body of this letter. 
   */   
   public void addLine(String line)
   {
       
       body=body.concat(line).concat("\n");
   }
   
   /**
      Gets the text of this letter.
   */
   public String getText() 
   {
      letter= letter.concat("Dear "+ recipient+ ": "+ "\n");
      letter = letter.concat("\n");
      letter =letter.concat(body);
      letter = letter.concat("\n");
      letter= letter.concat("Sincerely,").concat("\n");
      letter = letter.concat("\n");
      letter =letter.concat(sender);
      //System.out.print(letter);
      return letter;
      
   }
}

